"use strict";

/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 *
 * Modifications Copyright OpenSearch Contributors. See
 * GitHub history for details.
 */

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
module.exports = {
  rootDir: "../",
  setupFiles: ["<rootDir>/test/polyfills.ts", "<rootDir>/test/setupTests.ts"],
  setupFilesAfterEnv: ["<rootDir>/test/setup.jest.ts"],
  roots: ["<rootDir>"],
  coverageDirectory: "./coverage",
  moduleNameMapper: {
    "\\.(css|less|scss)$": "<rootDir>/test/mocks/styleMock.ts",
    "^ui/(.*)": "<rootDir>/../../src/legacy/ui/public/$1/"
  },
  coverageReporters: ["lcov", "text", "cobertura"],
  testMatch: ["**/*.test.js", "**/*.test.jsx", "**/*.test.ts", "**/*.test.tsx"],
  collectCoverageFrom: ["**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx", "!**/models/**", "!**/node_modules/**", "!**/index.ts", "!<rootDir>/index.js", "!<rootDir>/public/app.js", "!<rootDir>/public/temporary/**", "!<rootDir>/babel.config.js", "!<rootDir>/test/**", "!<rootDir>/server/**", "!<rootDir>/coverage/**", "!<rootDir>/scripts/**", "!<rootDir>/build/**", "!<rootDir>/cypress/**", "!**/vendor/**"],
  clearMocks: true,
  testPathIgnorePatterns: ["<rootDir>/build/", "<rootDir>/node_modules/"],
  modulePathIgnorePatterns: ["indexManagementDashboards"]
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImplc3QuY29uZmlnLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiLCJyb290RGlyIiwic2V0dXBGaWxlcyIsInNldHVwRmlsZXNBZnRlckVudiIsInJvb3RzIiwiY292ZXJhZ2VEaXJlY3RvcnkiLCJtb2R1bGVOYW1lTWFwcGVyIiwiY292ZXJhZ2VSZXBvcnRlcnMiLCJ0ZXN0TWF0Y2giLCJjb2xsZWN0Q292ZXJhZ2VGcm9tIiwiY2xlYXJNb2NrcyIsInRlc3RQYXRoSWdub3JlUGF0dGVybnMiLCJtb2R1bGVQYXRoSWdub3JlUGF0dGVybnMiXSwibWFwcGluZ3MiOiI7O0FBQUE7Ozs7Ozs7Ozs7O0FBV0E7Ozs7Ozs7Ozs7Ozs7O0FBZUFBLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUNmQyxFQUFBQSxPQUFPLEVBQUUsS0FETTtBQUVmQyxFQUFBQSxVQUFVLEVBQUUsQ0FBQyw2QkFBRCxFQUFnQyw4QkFBaEMsQ0FGRztBQUdmQyxFQUFBQSxrQkFBa0IsRUFBRSxDQUFDLDhCQUFELENBSEw7QUFJZkMsRUFBQUEsS0FBSyxFQUFFLENBQUMsV0FBRCxDQUpRO0FBS2ZDLEVBQUFBLGlCQUFpQixFQUFFLFlBTEo7QUFNZkMsRUFBQUEsZ0JBQWdCLEVBQUU7QUFDaEIsMkJBQXVCLG1DQURQO0FBRWhCLGdCQUFZO0FBRkksR0FOSDtBQVVmQyxFQUFBQSxpQkFBaUIsRUFBRSxDQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLFdBQWpCLENBVko7QUFXZkMsRUFBQUEsU0FBUyxFQUFFLENBQUMsY0FBRCxFQUFpQixlQUFqQixFQUFrQyxjQUFsQyxFQUFrRCxlQUFsRCxDQVhJO0FBWWZDLEVBQUFBLG1CQUFtQixFQUFFLENBQ25CLFNBRG1CLEVBRW5CLFVBRm1CLEVBR25CLFNBSG1CLEVBSW5CLFVBSm1CLEVBS25CLGVBTG1CLEVBTW5CLHFCQU5tQixFQU9uQixjQVBtQixFQVFuQixxQkFSbUIsRUFTbkIsMEJBVG1CLEVBVW5CLGdDQVZtQixFQVduQiw0QkFYbUIsRUFZbkIsb0JBWm1CLEVBYW5CLHNCQWJtQixFQWNuQix3QkFkbUIsRUFlbkIsdUJBZm1CLEVBZ0JuQixxQkFoQm1CLEVBaUJuQix1QkFqQm1CLEVBa0JuQixlQWxCbUIsQ0FaTjtBQWdDZkMsRUFBQUEsVUFBVSxFQUFFLElBaENHO0FBaUNmQyxFQUFBQSxzQkFBc0IsRUFBRSxDQUFDLGtCQUFELEVBQXFCLHlCQUFyQixDQWpDVDtBQWtDZkMsRUFBQUEsd0JBQXdCLEVBQUUsQ0FBQywyQkFBRDtBQWxDWCxDQUFqQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICpcbiAqIFRoZSBPcGVuU2VhcmNoIENvbnRyaWJ1dG9ycyByZXF1aXJlIGNvbnRyaWJ1dGlvbnMgbWFkZSB0b1xuICogdGhpcyBmaWxlIGJlIGxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUtMi4wIGxpY2Vuc2Ugb3IgYVxuICogY29tcGF0aWJsZSBvcGVuIHNvdXJjZSBsaWNlbnNlLlxuICpcbiAqIE1vZGlmaWNhdGlvbnMgQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzLiBTZWVcbiAqIEdpdEh1YiBoaXN0b3J5IGZvciBkZXRhaWxzLlxuICovXG5cbi8qXG4gKiBDb3B5cmlnaHQgMjAxOSBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xuICogcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICByb290RGlyOiBcIi4uL1wiLFxuICBzZXR1cEZpbGVzOiBbXCI8cm9vdERpcj4vdGVzdC9wb2x5ZmlsbHMudHNcIiwgXCI8cm9vdERpcj4vdGVzdC9zZXR1cFRlc3RzLnRzXCJdLFxuICBzZXR1cEZpbGVzQWZ0ZXJFbnY6IFtcIjxyb290RGlyPi90ZXN0L3NldHVwLmplc3QudHNcIl0sXG4gIHJvb3RzOiBbXCI8cm9vdERpcj5cIl0sXG4gIGNvdmVyYWdlRGlyZWN0b3J5OiBcIi4vY292ZXJhZ2VcIixcbiAgbW9kdWxlTmFtZU1hcHBlcjoge1xuICAgIFwiXFxcXC4oY3NzfGxlc3N8c2NzcykkXCI6IFwiPHJvb3REaXI+L3Rlc3QvbW9ja3Mvc3R5bGVNb2NrLnRzXCIsXG4gICAgXCJedWkvKC4qKVwiOiBcIjxyb290RGlyPi8uLi8uLi9zcmMvbGVnYWN5L3VpL3B1YmxpYy8kMS9cIixcbiAgfSxcbiAgY292ZXJhZ2VSZXBvcnRlcnM6IFtcImxjb3ZcIiwgXCJ0ZXh0XCIsIFwiY29iZXJ0dXJhXCJdLFxuICB0ZXN0TWF0Y2g6IFtcIioqLyoudGVzdC5qc1wiLCBcIioqLyoudGVzdC5qc3hcIiwgXCIqKi8qLnRlc3QudHNcIiwgXCIqKi8qLnRlc3QudHN4XCJdLFxuICBjb2xsZWN0Q292ZXJhZ2VGcm9tOiBbXG4gICAgXCIqKi8qLnRzXCIsXG4gICAgXCIqKi8qLnRzeFwiLFxuICAgIFwiKiovKi5qc1wiLFxuICAgIFwiKiovKi5qc3hcIixcbiAgICBcIiEqKi9tb2RlbHMvKipcIixcbiAgICBcIiEqKi9ub2RlX21vZHVsZXMvKipcIixcbiAgICBcIiEqKi9pbmRleC50c1wiLFxuICAgIFwiITxyb290RGlyPi9pbmRleC5qc1wiLFxuICAgIFwiITxyb290RGlyPi9wdWJsaWMvYXBwLmpzXCIsXG4gICAgXCIhPHJvb3REaXI+L3B1YmxpYy90ZW1wb3JhcnkvKipcIixcbiAgICBcIiE8cm9vdERpcj4vYmFiZWwuY29uZmlnLmpzXCIsXG4gICAgXCIhPHJvb3REaXI+L3Rlc3QvKipcIixcbiAgICBcIiE8cm9vdERpcj4vc2VydmVyLyoqXCIsXG4gICAgXCIhPHJvb3REaXI+L2NvdmVyYWdlLyoqXCIsXG4gICAgXCIhPHJvb3REaXI+L3NjcmlwdHMvKipcIixcbiAgICBcIiE8cm9vdERpcj4vYnVpbGQvKipcIixcbiAgICBcIiE8cm9vdERpcj4vY3lwcmVzcy8qKlwiLFxuICAgIFwiISoqL3ZlbmRvci8qKlwiLFxuICBdLFxuICBjbGVhck1vY2tzOiB0cnVlLFxuICB0ZXN0UGF0aElnbm9yZVBhdHRlcm5zOiBbXCI8cm9vdERpcj4vYnVpbGQvXCIsIFwiPHJvb3REaXI+L25vZGVfbW9kdWxlcy9cIl0sXG4gIG1vZHVsZVBhdGhJZ25vcmVQYXR0ZXJuczogW1wiaW5kZXhNYW5hZ2VtZW50RGFzaGJvYXJkc1wiXSxcbn07XG4iXX0=