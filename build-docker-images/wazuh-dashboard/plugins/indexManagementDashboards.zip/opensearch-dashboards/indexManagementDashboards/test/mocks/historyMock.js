"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 *
 * Modifications Copyright OpenSearch Contributors. See
 * GitHub history for details.
 */

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
const historyMock = {
  action: "REPLACE",
  // PUSH, REPLACE, POP
  block: jest.fn(),
  // prevents navigation
  createHref: jest.fn(),
  go: jest.fn(),
  // moves the pointer in the history stack by n entries
  goBack: jest.fn(),
  // equivalent to go(-1)
  goForward: jest.fn(),
  // equivalent to go(1)
  length: 0,
  // number of entries in the history stack
  listen: jest.fn(),
  location: {
    hash: "",
    // URL hash fragment
    pathname: "",
    // path of URL
    search: "",
    // URL query string
    state: undefined // location-specific state that was provided to e.g. push(path, state) when this location was pushed onto the stack

  },
  push: jest.fn(),
  // pushes new entry onto history stack
  replace: jest.fn() // replaces current entry on history stack

};
var _default = historyMock;
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpc3RvcnlNb2NrLnRzIl0sIm5hbWVzIjpbImhpc3RvcnlNb2NrIiwiYWN0aW9uIiwiYmxvY2siLCJqZXN0IiwiZm4iLCJjcmVhdGVIcmVmIiwiZ28iLCJnb0JhY2siLCJnb0ZvcndhcmQiLCJsZW5ndGgiLCJsaXN0ZW4iLCJsb2NhdGlvbiIsImhhc2giLCJwYXRobmFtZSIsInNlYXJjaCIsInN0YXRlIiwidW5kZWZpbmVkIiwicHVzaCIsInJlcGxhY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7QUFXQTs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsTUFBTUEsV0FBc0IsR0FBRztBQUM3QkMsRUFBQUEsTUFBTSxFQUFFLFNBRHFCO0FBQ1Y7QUFDbkJDLEVBQUFBLEtBQUssRUFBRUMsSUFBSSxDQUFDQyxFQUFMLEVBRnNCO0FBRVg7QUFDbEJDLEVBQUFBLFVBQVUsRUFBRUYsSUFBSSxDQUFDQyxFQUFMLEVBSGlCO0FBSTdCRSxFQUFBQSxFQUFFLEVBQUVILElBQUksQ0FBQ0MsRUFBTCxFQUp5QjtBQUlkO0FBQ2ZHLEVBQUFBLE1BQU0sRUFBRUosSUFBSSxDQUFDQyxFQUFMLEVBTHFCO0FBS1Y7QUFDbkJJLEVBQUFBLFNBQVMsRUFBRUwsSUFBSSxDQUFDQyxFQUFMLEVBTmtCO0FBTVA7QUFDdEJLLEVBQUFBLE1BQU0sRUFBRSxDQVBxQjtBQU9sQjtBQUNYQyxFQUFBQSxNQUFNLEVBQUVQLElBQUksQ0FBQ0MsRUFBTCxFQVJxQjtBQVM3Qk8sRUFBQUEsUUFBUSxFQUFFO0FBQ1JDLElBQUFBLElBQUksRUFBRSxFQURFO0FBQ0U7QUFDVkMsSUFBQUEsUUFBUSxFQUFFLEVBRkY7QUFFTTtBQUNkQyxJQUFBQSxNQUFNLEVBQUUsRUFIQTtBQUdJO0FBQ1pDLElBQUFBLEtBQUssRUFBRUMsU0FKQyxDQUlVOztBQUpWLEdBVG1CO0FBZTdCQyxFQUFBQSxJQUFJLEVBQUVkLElBQUksQ0FBQ0MsRUFBTCxFQWZ1QjtBQWVaO0FBQ2pCYyxFQUFBQSxPQUFPLEVBQUVmLElBQUksQ0FBQ0MsRUFBTCxFQWhCb0IsQ0FnQlQ7O0FBaEJTLENBQS9CO2VBbUJlSixXIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKlxuICogVGhlIE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzIHJlcXVpcmUgY29udHJpYnV0aW9ucyBtYWRlIHRvXG4gKiB0aGlzIGZpbGUgYmUgbGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZS0yLjAgbGljZW5zZSBvciBhXG4gKiBjb21wYXRpYmxlIG9wZW4gc291cmNlIGxpY2Vuc2UuXG4gKlxuICogTW9kaWZpY2F0aW9ucyBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnMuIFNlZVxuICogR2l0SHViIGhpc3RvcnkgZm9yIGRldGFpbHMuXG4gKi9cblxuLypcbiAqIENvcHlyaWdodCAyMDE5IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS5cbiAqIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogb3IgaW4gdGhlIFwibGljZW5zZVwiIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkXG4gKiBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiBwZXJtaXNzaW9ucyBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cbmltcG9ydCAqIGFzIEggZnJvbSBcImhpc3RvcnlcIjtcblxuY29uc3QgaGlzdG9yeU1vY2s6IEguSGlzdG9yeSA9IHtcbiAgYWN0aW9uOiBcIlJFUExBQ0VcIiwgLy8gUFVTSCwgUkVQTEFDRSwgUE9QXG4gIGJsb2NrOiBqZXN0LmZuKCksIC8vIHByZXZlbnRzIG5hdmlnYXRpb25cbiAgY3JlYXRlSHJlZjogamVzdC5mbigpLFxuICBnbzogamVzdC5mbigpLCAvLyBtb3ZlcyB0aGUgcG9pbnRlciBpbiB0aGUgaGlzdG9yeSBzdGFjayBieSBuIGVudHJpZXNcbiAgZ29CYWNrOiBqZXN0LmZuKCksIC8vIGVxdWl2YWxlbnQgdG8gZ28oLTEpXG4gIGdvRm9yd2FyZDogamVzdC5mbigpLCAvLyBlcXVpdmFsZW50IHRvIGdvKDEpXG4gIGxlbmd0aDogMCwgLy8gbnVtYmVyIG9mIGVudHJpZXMgaW4gdGhlIGhpc3Rvcnkgc3RhY2tcbiAgbGlzdGVuOiBqZXN0LmZuKCksXG4gIGxvY2F0aW9uOiB7XG4gICAgaGFzaDogXCJcIiwgLy8gVVJMIGhhc2ggZnJhZ21lbnRcbiAgICBwYXRobmFtZTogXCJcIiwgLy8gcGF0aCBvZiBVUkxcbiAgICBzZWFyY2g6IFwiXCIsIC8vIFVSTCBxdWVyeSBzdHJpbmdcbiAgICBzdGF0ZTogdW5kZWZpbmVkLCAvLyBsb2NhdGlvbi1zcGVjaWZpYyBzdGF0ZSB0aGF0IHdhcyBwcm92aWRlZCB0byBlLmcuIHB1c2gocGF0aCwgc3RhdGUpIHdoZW4gdGhpcyBsb2NhdGlvbiB3YXMgcHVzaGVkIG9udG8gdGhlIHN0YWNrXG4gIH0sXG4gIHB1c2g6IGplc3QuZm4oKSwgLy8gcHVzaGVzIG5ldyBlbnRyeSBvbnRvIGhpc3Rvcnkgc3RhY2tcbiAgcmVwbGFjZTogamVzdC5mbigpLCAvLyByZXBsYWNlcyBjdXJyZW50IGVudHJ5IG9uIGhpc3Rvcnkgc3RhY2tcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGhpc3RvcnlNb2NrO1xuIl19