"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ProxyAuthRoutes = void 0;

var _configSchema = require("@osd/config-schema");

var _next_url = require("../../../utils/next_url");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class ProxyAuthRoutes {
  constructor(router, config, sessionStorageFactory, securityClient, coreSetup) {
    this.router = router;
    this.config = config;
    this.sessionStorageFactory = sessionStorageFactory;
    this.securityClient = securityClient;
    this.coreSetup = coreSetup;
  }

  setupRoutes() {
    this.router.get({
      path: `/auth/proxy/login`,
      validate: {
        query: _configSchema.schema.object({
          nextUrl: _configSchema.schema.maybe(_configSchema.schema.string({
            validate: _next_url.validateNextUrl
          }))
        })
      },
      options: {
        // TODO: set to false?
        authRequired: 'optional'
      }
    }, async (context, request, response) => {
      var _this$config$proxycac;

      if (request.auth.isAuthenticated) {
        const nextUrl = request.query.nextUrl || `${this.coreSetup.http.basePath.serverBasePath}/app/opensearch-dashboards`;
        response.redirected({
          headers: {
            location: nextUrl
          }
        });
      }

      const loginEndpoint = (_this$config$proxycac = this.config.proxycache) === null || _this$config$proxycac === void 0 ? void 0 : _this$config$proxycac.login_endpoint;

      if (loginEndpoint) {
        return response.redirected({
          headers: {
            location: loginEndpoint
          }
        });
      } else {
        return response.badRequest();
      }
    });
    this.router.post({
      path: `/auth/proxy/logout`,
      validate: false
    }, async (context, request, response) => {
      this.sessionStorageFactory.asScoped(request).clear();
      return response.ok();
    });
  }

}

exports.ProxyAuthRoutes = ProxyAuthRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlcy50cyJdLCJuYW1lcyI6WyJQcm94eUF1dGhSb3V0ZXMiLCJjb25zdHJ1Y3RvciIsInJvdXRlciIsImNvbmZpZyIsInNlc3Npb25TdG9yYWdlRmFjdG9yeSIsInNlY3VyaXR5Q2xpZW50IiwiY29yZVNldHVwIiwic2V0dXBSb3V0ZXMiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsIm5leHRVcmwiLCJtYXliZSIsInN0cmluZyIsInZhbGlkYXRlTmV4dFVybCIsIm9wdGlvbnMiLCJhdXRoUmVxdWlyZWQiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiYXV0aCIsImlzQXV0aGVudGljYXRlZCIsImh0dHAiLCJiYXNlUGF0aCIsInNlcnZlckJhc2VQYXRoIiwicmVkaXJlY3RlZCIsImhlYWRlcnMiLCJsb2NhdGlvbiIsImxvZ2luRW5kcG9pbnQiLCJwcm94eWNhY2hlIiwibG9naW5fZW5kcG9pbnQiLCJiYWRSZXF1ZXN0IiwicG9zdCIsImFzU2NvcGVkIiwiY2xlYXIiLCJvayJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWVBOztBQU1BOztBQXJCQTs7Ozs7Ozs7Ozs7Ozs7QUF1Qk8sTUFBTUEsZUFBTixDQUFzQjtBQUMzQkMsRUFBQUEsV0FBVyxDQUNRQyxNQURSLEVBRVFDLE1BRlIsRUFHUUMscUJBSFIsRUFJUUMsY0FKUixFQUtRQyxTQUxSLEVBTVQ7QUFBQSxTQUxpQkosTUFLakIsR0FMaUJBLE1BS2pCO0FBQUEsU0FKaUJDLE1BSWpCLEdBSmlCQSxNQUlqQjtBQUFBLFNBSGlCQyxxQkFHakIsR0FIaUJBLHFCQUdqQjtBQUFBLFNBRmlCQyxjQUVqQixHQUZpQkEsY0FFakI7QUFBQSxTQURpQkMsU0FDakIsR0FEaUJBLFNBQ2pCO0FBQUU7O0FBRUdDLEVBQUFBLFdBQVAsR0FBcUI7QUFDbkIsU0FBS0wsTUFBTCxDQUFZTSxHQUFaLENBQ0U7QUFDRUMsTUFBQUEsSUFBSSxFQUFHLG1CQURUO0FBRUVDLE1BQUFBLFFBQVEsRUFBRTtBQUNSQyxRQUFBQSxLQUFLLEVBQUVDLHFCQUFPQyxNQUFQLENBQWM7QUFDbkJDLFVBQUFBLE9BQU8sRUFBRUYscUJBQU9HLEtBQVAsQ0FDUEgscUJBQU9JLE1BQVAsQ0FBYztBQUNaTixZQUFBQSxRQUFRLEVBQUVPO0FBREUsV0FBZCxDQURPO0FBRFUsU0FBZDtBQURDLE9BRlo7QUFXRUMsTUFBQUEsT0FBTyxFQUFFO0FBQ1A7QUFDQUMsUUFBQUEsWUFBWSxFQUFFO0FBRlA7QUFYWCxLQURGLEVBaUJFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUFBOztBQUNwQyxVQUFJRCxPQUFPLENBQUNFLElBQVIsQ0FBYUMsZUFBakIsRUFBa0M7QUFDaEMsY0FBTVYsT0FBTyxHQUNYTyxPQUFPLENBQUNWLEtBQVIsQ0FBY0csT0FBZCxJQUNDLEdBQUUsS0FBS1IsU0FBTCxDQUFlbUIsSUFBZixDQUFvQkMsUUFBcEIsQ0FBNkJDLGNBQWUsNEJBRmpEO0FBR0FMLFFBQUFBLFFBQVEsQ0FBQ00sVUFBVCxDQUFvQjtBQUNsQkMsVUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFlBQUFBLFFBQVEsRUFBRWhCO0FBREg7QUFEUyxTQUFwQjtBQUtEOztBQUVELFlBQU1pQixhQUFhLDRCQUFHLEtBQUs1QixNQUFMLENBQVk2QixVQUFmLDBEQUFHLHNCQUF3QkMsY0FBOUM7O0FBQ0EsVUFBSUYsYUFBSixFQUFtQjtBQUNqQixlQUFPVCxRQUFRLENBQUNNLFVBQVQsQ0FBb0I7QUFDekJDLFVBQUFBLE9BQU8sRUFBRTtBQUNQQyxZQUFBQSxRQUFRLEVBQUVDO0FBREg7QUFEZ0IsU0FBcEIsQ0FBUDtBQUtELE9BTkQsTUFNTztBQUNMLGVBQU9ULFFBQVEsQ0FBQ1ksVUFBVCxFQUFQO0FBQ0Q7QUFDRixLQXZDSDtBQTBDQSxTQUFLaEMsTUFBTCxDQUFZaUMsSUFBWixDQUNFO0FBQ0UxQixNQUFBQSxJQUFJLEVBQUcsb0JBRFQ7QUFFRUMsTUFBQUEsUUFBUSxFQUFFO0FBRlosS0FERixFQUtFLE9BQU9VLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxXQUFLbEIscUJBQUwsQ0FBMkJnQyxRQUEzQixDQUFvQ2YsT0FBcEMsRUFBNkNnQixLQUE3QztBQUNBLGFBQU9mLFFBQVEsQ0FBQ2dCLEVBQVQsRUFBUDtBQUNELEtBUkg7QUFVRDs7QUE5RDBCIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKlxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogICBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqICAgb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHsgSVJvdXRlciwgU2Vzc2lvblN0b3JhZ2VGYWN0b3J5IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB9IGZyb20gJy4uLy4uLy4uL3Nlc3Npb24vc2VjdXJpdHlfY29va2llJztcbmltcG9ydCB7IFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZSB9IGZyb20gJy4uLy4uLy4uJztcbmltcG9ydCB7IFNlY3VyaXR5Q2xpZW50IH0gZnJvbSAnLi4vLi4vLi4vYmFja2VuZC9vcGVuc2VhcmNoX3NlY3VyaXR5X2NsaWVudCc7XG5pbXBvcnQgeyBDb3JlU2V0dXAgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgdmFsaWRhdGVOZXh0VXJsIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbmV4dF91cmwnO1xuXG5leHBvcnQgY2xhc3MgUHJveHlBdXRoUm91dGVzIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZWFkb25seSByb3V0ZXI6IElSb3V0ZXIsXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb25maWc6IFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZSxcbiAgICBwcml2YXRlIHJlYWRvbmx5IHNlc3Npb25TdG9yYWdlRmFjdG9yeTogU2Vzc2lvblN0b3JhZ2VGYWN0b3J5PFNlY3VyaXR5U2Vzc2lvbkNvb2tpZT4sXG4gICAgcHJpdmF0ZSByZWFkb25seSBzZWN1cml0eUNsaWVudDogU2VjdXJpdHlDbGllbnQsXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb3JlU2V0dXA6IENvcmVTZXR1cFxuICApIHt9XG5cbiAgcHVibGljIHNldHVwUm91dGVzKCkge1xuICAgIHRoaXMucm91dGVyLmdldChcbiAgICAgIHtcbiAgICAgICAgcGF0aDogYC9hdXRoL3Byb3h5L2xvZ2luYCxcbiAgICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgICBuZXh0VXJsOiBzY2hlbWEubWF5YmUoXG4gICAgICAgICAgICAgIHNjaGVtYS5zdHJpbmcoe1xuICAgICAgICAgICAgICAgIHZhbGlkYXRlOiB2YWxpZGF0ZU5leHRVcmwsXG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9LFxuICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgLy8gVE9ETzogc2V0IHRvIGZhbHNlP1xuICAgICAgICAgIGF1dGhSZXF1aXJlZDogJ29wdGlvbmFsJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgICAgaWYgKHJlcXVlc3QuYXV0aC5pc0F1dGhlbnRpY2F0ZWQpIHtcbiAgICAgICAgICBjb25zdCBuZXh0VXJsID1cbiAgICAgICAgICAgIHJlcXVlc3QucXVlcnkubmV4dFVybCB8fFxuICAgICAgICAgICAgYCR7dGhpcy5jb3JlU2V0dXAuaHR0cC5iYXNlUGF0aC5zZXJ2ZXJCYXNlUGF0aH0vYXBwL29wZW5zZWFyY2gtZGFzaGJvYXJkc2A7XG4gICAgICAgICAgcmVzcG9uc2UucmVkaXJlY3RlZCh7XG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgIGxvY2F0aW9uOiBuZXh0VXJsLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGxvZ2luRW5kcG9pbnQgPSB0aGlzLmNvbmZpZy5wcm94eWNhY2hlPy5sb2dpbl9lbmRwb2ludDtcbiAgICAgICAgaWYgKGxvZ2luRW5kcG9pbnQpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UucmVkaXJlY3RlZCh7XG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgIGxvY2F0aW9uOiBsb2dpbkVuZHBvaW50LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgKTtcblxuICAgIHRoaXMucm91dGVyLnBvc3QoXG4gICAgICB7XG4gICAgICAgIHBhdGg6IGAvYXV0aC9wcm94eS9sb2dvdXRgLFxuICAgICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICB9LFxuICAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIHRoaXMuc2Vzc2lvblN0b3JhZ2VGYWN0b3J5LmFzU2NvcGVkKHJlcXVlc3QpLmNsZWFyKCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vaygpO1xuICAgICAgfVxuICAgICk7XG4gIH1cbn1cbiJdfQ==