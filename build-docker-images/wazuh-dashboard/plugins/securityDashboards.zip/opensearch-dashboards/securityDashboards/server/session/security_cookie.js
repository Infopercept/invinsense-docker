"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getSecurityCookieOptions = getSecurityCookieOptions;
exports.clearOldVersionCookieValue = clearOldVersionCookieValue;

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function getSecurityCookieOptions(config) {
  return {
    name: config.cookie.name,
    encryptionKey: config.cookie.password,
    validate: sessionStorage => {
      sessionStorage = sessionStorage;

      if (sessionStorage === undefined) {
        return {
          isValid: false,
          path: '/'
        };
      } // TODO: with setting redirect attributes to support OIDC and SAML,
      //       we need to do additonal cookie validatin in AuthenticationHandlers.
      // if SAML fields present


      if (sessionStorage.saml && sessionStorage.saml.requestId && sessionStorage.saml.nextUrl) {
        return {
          isValid: true,
          path: '/'
        };
      } // if OIDC fields present


      if (sessionStorage.oidc) {
        return {
          isValid: true,
          path: '/'
        };
      }

      if (sessionStorage.expiryTime === undefined || sessionStorage.expiryTime < Date.now()) {
        return {
          isValid: false,
          path: '/'
        };
      }

      return {
        isValid: true,
        path: '/'
      };
    },
    isSecure: config.cookie.secure,
    sameSite: config.cookie.isSameSite || undefined
  };
}

function clearOldVersionCookieValue(config) {
  if (config.cookie.secure) {
    return 'security_authentication=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; Path=/';
  } else {
    return 'security_authentication=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Path=/';
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlY3VyaXR5X2Nvb2tpZS50cyJdLCJuYW1lcyI6WyJnZXRTZWN1cml0eUNvb2tpZU9wdGlvbnMiLCJjb25maWciLCJuYW1lIiwiY29va2llIiwiZW5jcnlwdGlvbktleSIsInBhc3N3b3JkIiwidmFsaWRhdGUiLCJzZXNzaW9uU3RvcmFnZSIsInVuZGVmaW5lZCIsImlzVmFsaWQiLCJwYXRoIiwic2FtbCIsInJlcXVlc3RJZCIsIm5leHRVcmwiLCJvaWRjIiwiZXhwaXJ5VGltZSIsIkRhdGUiLCJub3ciLCJpc1NlY3VyZSIsInNlY3VyZSIsInNhbWVTaXRlIiwiaXNTYW1lU2l0ZSIsImNsZWFyT2xkVmVyc2lvbkNvb2tpZVZhbHVlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7OztBQXlDTyxTQUFTQSx3QkFBVCxDQUNMQyxNQURLLEVBRStDO0FBQ3BELFNBQU87QUFDTEMsSUFBQUEsSUFBSSxFQUFFRCxNQUFNLENBQUNFLE1BQVAsQ0FBY0QsSUFEZjtBQUVMRSxJQUFBQSxhQUFhLEVBQUVILE1BQU0sQ0FBQ0UsTUFBUCxDQUFjRSxRQUZ4QjtBQUdMQyxJQUFBQSxRQUFRLEVBQUdDLGNBQUQsSUFBcUU7QUFDN0VBLE1BQUFBLGNBQWMsR0FBR0EsY0FBakI7O0FBQ0EsVUFBSUEsY0FBYyxLQUFLQyxTQUF2QixFQUFrQztBQUNoQyxlQUFPO0FBQUVDLFVBQUFBLE9BQU8sRUFBRSxLQUFYO0FBQWtCQyxVQUFBQSxJQUFJLEVBQUU7QUFBeEIsU0FBUDtBQUNELE9BSjRFLENBTTdFO0FBQ0E7QUFDQTs7O0FBQ0EsVUFBSUgsY0FBYyxDQUFDSSxJQUFmLElBQXVCSixjQUFjLENBQUNJLElBQWYsQ0FBb0JDLFNBQTNDLElBQXdETCxjQUFjLENBQUNJLElBQWYsQ0FBb0JFLE9BQWhGLEVBQXlGO0FBQ3ZGLGVBQU87QUFBRUosVUFBQUEsT0FBTyxFQUFFLElBQVg7QUFBaUJDLFVBQUFBLElBQUksRUFBRTtBQUF2QixTQUFQO0FBQ0QsT0FYNEUsQ0FhN0U7OztBQUNBLFVBQUlILGNBQWMsQ0FBQ08sSUFBbkIsRUFBeUI7QUFDdkIsZUFBTztBQUFFTCxVQUFBQSxPQUFPLEVBQUUsSUFBWDtBQUFpQkMsVUFBQUEsSUFBSSxFQUFFO0FBQXZCLFNBQVA7QUFDRDs7QUFFRCxVQUFJSCxjQUFjLENBQUNRLFVBQWYsS0FBOEJQLFNBQTlCLElBQTJDRCxjQUFjLENBQUNRLFVBQWYsR0FBNEJDLElBQUksQ0FBQ0MsR0FBTCxFQUEzRSxFQUF1RjtBQUNyRixlQUFPO0FBQUVSLFVBQUFBLE9BQU8sRUFBRSxLQUFYO0FBQWtCQyxVQUFBQSxJQUFJLEVBQUU7QUFBeEIsU0FBUDtBQUNEOztBQUNELGFBQU87QUFBRUQsUUFBQUEsT0FBTyxFQUFFLElBQVg7QUFBaUJDLFFBQUFBLElBQUksRUFBRTtBQUF2QixPQUFQO0FBQ0QsS0F6Qkk7QUEwQkxRLElBQUFBLFFBQVEsRUFBRWpCLE1BQU0sQ0FBQ0UsTUFBUCxDQUFjZ0IsTUExQm5CO0FBMkJMQyxJQUFBQSxRQUFRLEVBQUVuQixNQUFNLENBQUNFLE1BQVAsQ0FBY2tCLFVBQWQsSUFBNEJiO0FBM0JqQyxHQUFQO0FBNkJEOztBQUVNLFNBQVNjLDBCQUFULENBQW9DckIsTUFBcEMsRUFBOEU7QUFDbkYsTUFBSUEsTUFBTSxDQUFDRSxNQUFQLENBQWNnQixNQUFsQixFQUEwQjtBQUN4QixXQUFPLHNHQUFQO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsV0FBTyw4RkFBUDtBQUNEO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IFNlc3Npb25TdG9yYWdlQ29va2llT3B0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBTZWN1cml0eVBsdWdpbkNvbmZpZ1R5cGUgfSBmcm9tICcuLic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2VjdXJpdHlTZXNzaW9uQ29va2llIHtcbiAgLy8gc2VjdXJpdHlfYXV0aGVudGljYXRpb25cbiAgdXNlcm5hbWU/OiBzdHJpbmc7XG4gIGNyZWRlbnRpYWxzPzogYW55O1xuICBhdXRoVHlwZT86IHN0cmluZztcbiAgYXNzaWduQXV0aEhlYWRlcj86IGJvb2xlYW47XG4gIGlzQW5vbnltb3VzQXV0aD86IGJvb2xlYW47XG4gIGV4cGlyeVRpbWU/OiBudW1iZXI7XG4gIGFkZGl0aW9uYWxBdXRoSGVhZGVycz86IGFueTtcblxuICAvLyBzZWN1cml0eV9zdG9yYWdlXG4gIHRlbmFudD86IGFueTtcblxuICAvLyBmb3Igb2lkYyBhdXRoIHdvcmtmbG93XG4gIG9pZGM/OiBhbnk7XG5cbiAgLy8gZm9yIFNhbWwgYXV0aCB3b3JrZmxvd1xuICBzYW1sPzoge1xuICAgIHJlcXVlc3RJZD86IHN0cmluZztcbiAgICBuZXh0VXJsPzogc3RyaW5nO1xuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VjdXJpdHlDb29raWVPcHRpb25zKFxuICBjb25maWc6IFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZVxuKTogU2Vzc2lvblN0b3JhZ2VDb29raWVPcHRpb25zPFNlY3VyaXR5U2Vzc2lvbkNvb2tpZT4ge1xuICByZXR1cm4ge1xuICAgIG5hbWU6IGNvbmZpZy5jb29raWUubmFtZSxcbiAgICBlbmNyeXB0aW9uS2V5OiBjb25maWcuY29va2llLnBhc3N3b3JkLFxuICAgIHZhbGlkYXRlOiAoc2Vzc2lvblN0b3JhZ2U6IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB8IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZVtdKSA9PiB7XG4gICAgICBzZXNzaW9uU3RvcmFnZSA9IHNlc3Npb25TdG9yYWdlIGFzIFNlY3VyaXR5U2Vzc2lvbkNvb2tpZTtcbiAgICAgIGlmIChzZXNzaW9uU3RvcmFnZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQ6IGZhbHNlLCBwYXRoOiAnLycgfTtcbiAgICAgIH1cblxuICAgICAgLy8gVE9ETzogd2l0aCBzZXR0aW5nIHJlZGlyZWN0IGF0dHJpYnV0ZXMgdG8gc3VwcG9ydCBPSURDIGFuZCBTQU1MLFxuICAgICAgLy8gICAgICAgd2UgbmVlZCB0byBkbyBhZGRpdG9uYWwgY29va2llIHZhbGlkYXRpbiBpbiBBdXRoZW50aWNhdGlvbkhhbmRsZXJzLlxuICAgICAgLy8gaWYgU0FNTCBmaWVsZHMgcHJlc2VudFxuICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLnNhbWwgJiYgc2Vzc2lvblN0b3JhZ2Uuc2FtbC5yZXF1ZXN0SWQgJiYgc2Vzc2lvblN0b3JhZ2Uuc2FtbC5uZXh0VXJsKSB7XG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQ6IHRydWUsIHBhdGg6ICcvJyB9O1xuICAgICAgfVxuXG4gICAgICAvLyBpZiBPSURDIGZpZWxkcyBwcmVzZW50XG4gICAgICBpZiAoc2Vzc2lvblN0b3JhZ2Uub2lkYykge1xuICAgICAgICByZXR1cm4geyBpc1ZhbGlkOiB0cnVlLCBwYXRoOiAnLycgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLmV4cGlyeVRpbWUgPT09IHVuZGVmaW5lZCB8fCBzZXNzaW9uU3RvcmFnZS5leHBpcnlUaW1lIDwgRGF0ZS5ub3coKSkge1xuICAgICAgICByZXR1cm4geyBpc1ZhbGlkOiBmYWxzZSwgcGF0aDogJy8nIH07XG4gICAgICB9XG4gICAgICByZXR1cm4geyBpc1ZhbGlkOiB0cnVlLCBwYXRoOiAnLycgfTtcbiAgICB9LFxuICAgIGlzU2VjdXJlOiBjb25maWcuY29va2llLnNlY3VyZSxcbiAgICBzYW1lU2l0ZTogY29uZmlnLmNvb2tpZS5pc1NhbWVTaXRlIHx8IHVuZGVmaW5lZCxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyT2xkVmVyc2lvbkNvb2tpZVZhbHVlKGNvbmZpZzogU2VjdXJpdHlQbHVnaW5Db25maWdUeXBlKTogc3RyaW5nIHtcbiAgaWYgKGNvbmZpZy5jb29raWUuc2VjdXJlKSB7XG4gICAgcmV0dXJuICdzZWN1cml0eV9hdXRoZW50aWNhdGlvbj07IE1heC1BZ2U9MDsgRXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIEdNVDsgU2VjdXJlOyBIdHRwT25seTsgUGF0aD0vJztcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gJ3NlY3VyaXR5X2F1dGhlbnRpY2F0aW9uPTsgTWF4LUFnZT0wOyBFeHBpcmVzPVRodSwgMDEgSmFuIDE5NzAgMDA6MDA6MDAgR01UOyBIdHRwT25seTsgUGF0aD0vJztcbiAgfVxufVxuIl19